# -*- coding: utf-8 -*-
from flask import Flask, jsonify
from flask_cors import CORS
from config import SECRET_KEY, DEBUG, CORS_ORIGINS, HOST, PORT
from models import init_db
from routes.auth import auth_bp
from routes.timesheet import timesheet_bp
from routes.template import template_bp
from routes.organization import org_bp
from routes.backup import backup_bp, start_backup_scheduler

app = Flask(__name__)
app.config['SECRET_KEY'] = SECRET_KEY
app.config['JSON_AS_ASCII'] = False

# 配置 CORS
CORS(app, origins=CORS_ORIGINS, supports_credentials=True)

# 注册蓝图（不含 AI 助手）
app.register_blueprint(auth_bp, url_prefix='/api/auth')
app.register_blueprint(timesheet_bp, url_prefix='/api/timesheet')
app.register_blueprint(template_bp, url_prefix='/api')
app.register_blueprint(org_bp, url_prefix='/api/organization')
app.register_blueprint(backup_bp, url_prefix='/api/backup')

# 健康检查
@app.route('/api/health', methods=['GET'])
def health_check():
    return jsonify({'status': 'ok', 'message': '服务运行正常'})

# 错误处理
@app.errorhandler(404)
def not_found(error):
    return jsonify({'success': False, 'message': '接口不存在'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'success': False, 'message': '服务器内部错误'}), 500

if __name__ == '__main__':
    # 初始化数据库
    init_db()
    
    # 启动备份调度器
    start_backup_scheduler()
    
    print(f"服务器启动中...")
    print(f"地址: http://{HOST}:{PORT}")
    print(f"数据库路径: /data/anydev/CTD-Timesheet-data/data/timesheet.db")
    
    app.run(host=HOST, port=PORT, debug=DEBUG)
